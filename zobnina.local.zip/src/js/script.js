console.log('script.js');

$('.gallery').slick({
	slidesToShow: 1,
});