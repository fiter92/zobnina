import 'slick-carousel';

import './js/script';

import 'slick-carousel/slick/slick.scss';
import 'slick-carousel/slick/slick-theme.scss';

import './css/main.scss';